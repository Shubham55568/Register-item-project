# register-items-project
A simple project with vanilla javascript to register products through a form.

Studie of manipulate the DOM with vanilla javascript. I'ts not finished yet, because I couldn't store the entire 'div' in localStorage broser.


This project have the goal of display the items registered in the panel form through submit button. So once the user press the submit button,
the Product is displayed in the space simulating the card product available in an e-commerce.


PROBLEMS

once we register the product and displayed in the space indicated, I wanted to use the LocalStorage to keep the product in the place simulating 
a data base, but I couldn't do it properly. I just could to register the prduct name, but not the other informations of the card product as description, quantity, price, etc.

*I need to improve my css file to get a better look  in the app sample, I'll do as soon as I can! :D

FEATURES
-Input form
-Product Name
-Product Description
-Quantity
-Price
-submit Button
-Search Filter
-Delete Button (in the product card)
-Clear Button (clear all products)
